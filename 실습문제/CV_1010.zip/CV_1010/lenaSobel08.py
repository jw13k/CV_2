import cv2
import numpy as np

# 이미지 불러오기
img = cv2.imread('lena.jpg')

# Sobel 에지 검출
sobelx=cv2.Sobel(img, -1, 1, 0, ksize=3) # x방향
sobely=cv2.Sobel(img, -1, 0, 1, ksize=3) # y방향

# 에지 강도 계산
edge_strength = cv2.addWeighted(sobelx, 0.5, sobely, 0.5, 0)

# 결과 시각화
cv2.imshow('Original', img)
cv2.imshow('Sobel X', sobelx)
cv2.imshow('Sobel Y', sobely)
cv2.imshow('Edge Strength', edge_strength)

cv2.waitKey(0)
cv2.destroyAllWindows()
