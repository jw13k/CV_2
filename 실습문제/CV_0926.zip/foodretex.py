import cv2
import numpy as np

image = cv2.imread('food.jpg')
# 대비와 밝기 조정 (대비 1.2배, 밝기 +30)
alpha = 1.5 # 대비 계수 (1보다 크면 대비 증가, 1보다 작으면 대비 감소)
beta = 15 # 밝기 증가 값 (양수면 밝기 증가, 음수면 밝기 감소)
# 대비와 밝기 조정 적용
adjusted_image = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
#cv2.imshow('Original Image', image)
#cv2.imshow('Adjusted Image (Contrast & Brightness)', adjusted_image)
# 조정된 이미지 저장
cv2.imwrite('adjusted_food.jpg', adjusted_image)

g = float(input("감마 값 : "))
img = cv2.imread('adjusted_food.jpg')
# 감마 변환 수행
out = img.copy()
out = out.astype(np.float32)
out = (out / 255) ** g * 255
out = out.astype(np.uint8)

cv2.imshow("original", img)
cv2.imshow("gamma", out) 

cv2.imwrite('gamma.jpg', out)

result = cv2.hconcat([image, adjusted_image, out])
cv2.imwrite('last.jpg', result)

cv2.waitKey(0)
cv2.destroyAllWindows()