import cv2
import numpy as np

image = cv2.imread('lena.jpg')

# 샤프닝 커널 정의
sharpen_kernel1 = np.array([[ 0, -1, 0],
                           [-1, 4, -1],
                           [ 1, -1, 0]])
sharpen_kernel2 = sharpen_kernel1.copy()
sharpen_kernel2[1, 1] = 4
sharpen_kernel3 = sharpen_kernel1.copy()

# 샤프닝 필터 적용
sharpened_image1 = cv2.filter2D(image, -1, sharpen_kernel1)
sharpened_image2 = cv2.filter2D(image, -1, sharpen_kernel2)
sharpened_image3 = cv2.filter2D(image, -1, sharpen_kernel3)

# 이미지 채널 조정 (BGR)
# 노란색 계열
sharpened_image2[:, :, 2] = 0  # Blue 채널을 0으로 설정
sharpened_image2[:, :, 0:2] = sharpened_image2[:, :, 0:2] * 1.5  # Red, Green 채널 값 증가

# 파란색 계열
sharpened_image3[:, :, 0:2] = 0  # Red, Green 채널을 0으로 설정
sharpened_image3[:, :, 1] = sharpened_image3[:, :, 2] * 1.5  # Blue 채널 값 증가

# 분홍색 계열 (예시)
sharpened_image1[:, :, 1] = 0  # Green 채널을 0으로 설정
sharpened_image1[:, :, 0:2] = sharpened_image1[:, :, 0:2] * 1.5  # Red, Blue 채널 값 증가

# 이미지 2x2 배치
# 1행 생성
row1 = cv2.hconcat([image, sharpened_image1])
row2 = cv2.hconcat([sharpened_image2, sharpened_image3])
# 2행을 세로로 연결
result = cv2.vconcat([row1, row2])

cv2.imwrite('lena2x2.jpg', result)

cv2.imshow('Sharpening Results', result)
cv2.waitKey(0)
cv2.destroyAllWindows()