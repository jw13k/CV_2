import cv2
# 이미지 읽기
image= cv2.imread('soccer.jpg')
# R, G, B 채널 분리 
B, G, R = cv2.split(image)
# 각각의 채널을 별도로 보여주기
cv2.imshow("Original Image", image)
cv2.imshow("Red Channel",R)
cv2.imshow("Green Channel",G)
cv2.imshow("Blue Channel",B)
#키 입력 대기
cv2.waitKey(0)
# 모든창 닫기
cv2.destroyAllWindows()
