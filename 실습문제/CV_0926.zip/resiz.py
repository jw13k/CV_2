import cv2
import numpy as np

arr = np.array([[10, 20, 30, 40],[50, 60, 70, 80],[90, 70, 80, 100],[110, 120, 130, 140]], dtype=np.uint8)

resize_dim = (200, 200)
# Nearest Neighbor 방식으로 리사이즈
resize_nn = cv2.resize(arr, resize_dim, interpolation=cv2.INTER_NEAREST)
# Bilinear 방식으로 리사이즈
resize_bilinear = cv2.resize(arr, resize_dim, interpolation=cv2.INTER_LINEAR)
# Bicubic 방식으로 리사이즈
resize_bicubic = cv2.resize(arr, resize_dim, interpolation=cv2.INTER_CUBIC)

result = cv2.hconcat([resize_nn, resize_bilinear, resize_bicubic])
cv2.imshow('Resized Comparison', result)
cv2.waitKey(0)
cv2.destroyAllWindows()