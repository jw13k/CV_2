import cv2
import numpy as np
image = cv2.imread('soccer.jpg')
# 1. 후추소금 노이즈 (Salt and Pepper Noise) 적용
def add_salt_and_pepper_noise(img, prob): # 확률에 따라 랜덤하게 픽셀을 흑백(0, 255)으로 설정
    noisy = img.copy()
    black = 0
    white = 255
    probs = np.random.rand(img.shape[0], img.shape[1])
    noisy[probs < prob] = black
    noisy[probs > 1 - prob] = white
    return noisy
salt_pepper_noise_img = add_salt_and_pepper_noise(image, 0.02) # 2% 확률로 노이즈 추가
cv2.imshow('Original Image', image)
cv2.imshow('Salt and Pepper Noise', salt_pepper_noise_img)
cv2.waitKey(0)
cv2.destroyAllWindows()
