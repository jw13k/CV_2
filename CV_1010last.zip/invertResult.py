import cv2
import numpy as np

# 이미지 읽기
img = cv2.imread('diary.jpg', cv2.IMREAD_GRAYSCALE)

# 이진화
binary_image = cv2.threshold(img, 100, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

# 모폴로지 연산 (팽창)
kernel = np.ones((2, 2), np.uint8)
dilated = cv2.dilate(binary_image, kernel, iterations=1)

eroded = cv2.erode(dilated, kernel, iterations=1)
opened = cv2.morphologyEx(eroded, cv2.MORPH_OPEN, kernel)
closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, kernel)

# 마스크 생성
mask = cv2.bitwise_not(closed)

# 원본 이미지와 마스크 합성
#result = cv2.bitwise_and(img, img, mask=mask)

# 결과 이미지 출력
cv2.imshow('Result', mask)
cv2.imwrite('ResultINVERT.jpg', mask)

cv2.waitKey(0)
cv2.destroyAllWindows()