import cv2
# SLIC 알고리즘 적용을 위해, pip install opencv-contrib-python로 추가모듈 설치 필요함
img = cv2.imread('lena.jpg')
slic = cv2.ximgproc.createSuperpixelSLIC(img, region_size=20, ruler=10.0)
slic.iterate(10) # 반복 횟수 설정
# 슈퍼픽셀의 마스크를 가져오기
mask_slic = slic.getLabelContourMask(thick_line=True)
# 결과를 시각화하기 위해 마스크 색 변경
mask_slic_inv = cv2.bitwise_not(mask_slic)
image_result = cv2.bitwise_and(img, img, mask=mask_slic_inv)
image_contours = cv2.bitwise_and(img, img, mask=mask_slic)
res = cv2.hconcat([img, image_contours, image_result])