import cv2
import numpy as np

# 이미지 불러오기
img = cv2.imread('20241010_111247.jpg')

laplacian = cv2.Laplacian(img, cv2.CV_8U)

canny = cv2.Canny(img, 100, 150)

lines =cv2.HoughLines(canny, 1, np.pi/10, 100)
 # 검출된직선그리기
for line in lines:
    rho, theta=line[0]
    a=np.cos(theta)
    b=np.sin(theta)
    x0=a*rho
    y0=b*rho

    x1=int(x0+1000*(-b))
    y1=int(y0+1000*(a))
    x2=int(x0-1000*(-b))
    y2=int(y0-1000*(a))

    cv2.line(img, (x1, y1), (x2, y2), (0, 255, 0), 2)

# 결과 시각화
cv2.imshow('houghline', img)
#cv2.imshow('laplacian', laplacian)
#cv2.imshow('canny', canny)

cv2.imwrite('houghline.jpg', img)

cv2.waitKey(0)
cv2.destroyAllWindows()
