import cv2
import numpy as np

# 이미지 불러오기
img = cv2.imread('cat.jpg')

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# 임계값 90
_, binary = cv2.threshold(gray, 90, 255, cv2.THRESH_BINARY_INV)
contours, hierarchy = cv2.findContours(binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

# 결과 시각화
cv2.imshow('Binary', binary)
cv2.imwrite('BinaryCAT.jpg', binary)

cv2.waitKey(0)
cv2.destroyAllWindows()
