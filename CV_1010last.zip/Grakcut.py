import cv2
import numpy as np

# 초기 설정

# 이미지 로드
img = cv2.imread('soccer.jpg')
img_copy = img.copy()  # 원본 이미지를 저장

mask = np.zeros(img.shape[:2], np.uint8)
rect = (0, 0, 1, 1)
rect_over = False
drawing = False
bgdModel = np.zeros((1, 65), np.float64)
fgdModel = np.zeros((1, 65), np.float64)

def mouse_callback(event, x, y, flags, param):
    global rect, rect_over, drawing, img, img_copy
    
    # 마우스 왼쪽 버튼을 눌렀을 때
    if event == cv2.EVENT_LBUTTONDOWN:
        rect = (x, y, x, y)
        drawing = True

    # 마우스를 움직였을 때
    elif event == cv2.EVENT_MOUSEMOVE:
        if drawing:
            img = img_copy.copy()  # 원본 이미지 유지
            cv2.rectangle(img, (rect[0], rect[1]), (x, y), (0, 255, 0), 2)

    # 마우스 왼쪽 버튼을 뗐을 때
    elif event == cv2.EVENT_LBUTTONUP:
        rect = (rect[0], rect[1], x, y)
        drawing = False
        rect_over = True
        cv2.rectangle(img, (rect[0], rect[1]), (x, y), (0, 255, 0), 2)

# 창 생성 및 마우스 콜백 등록
cv2.namedWindow('image')
cv2.setMouseCallback('image', mouse_callback)

while True:
    cv2.imshow('image', img)
    k = cv2.waitKey(1) & 0xFF

    if k == 27:  # ESC 키 누르면 종료
        break

    elif k == ord('r') and rect_over:  # r 키를 눌렀을 때 GrabCut 실행
        # GrabCut 실행
        cv2.grabCut(img_copy, mask, rect, bgdModel, fgdModel, 5, cv2.GC_INIT_WITH_RECT)
        
        # 마스크 기반으로 결과 이미지 생성
        mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
        img_result = img_copy * mask2[:, :, np.newaxis]

        # 결과 출력
        cv2.imshow('result', img_result)

    elif k == ord('c'):  # c 키를 누르면 이미지 리셋
        img = img_copy.copy()
        mask = np.zeros(img.shape[:2], np.uint8)
        rect_over = False

cv2.destroyAllWindows()
