import cv2
import numpy as np
# 두 이미지 읽기
img1 = cv2.imread('20241017_115738.jpg')
img2 = cv2.imread('20241017_115802.jpg')
# SIFT 검출기 생성
sift = cv2.SIFT_create()

# 특징점과 기술자 검출
kp1, des1 = sift.detectAndCompute(img1, None)
kp2, des2 = sift.detectAndCompute(img2, None)
# BFMatcher 생성
bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True)

# 매칭 수행
matches = bf.match(des1, des2)

# 매칭 결과를 거리 기준으로 정렬
matches = sorted(matches, key=lambda x: x.distance)
# 매칭된 특징점 좌표 추출
src_pts = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
dst_pts = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)

# RANSAC을 사용한 호모그래피 계산
M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 20.0)

# 인라이어와 아웃라이어 분류
matchesMask = mask.ravel().tolist()
# 매칭 결과 그리기
draw_params = dict(matchColor=(0, 255, 0),  # 인라이어는 초록색으로 표시
                   singlePointColor=None,
                   matchesMask=matchesMask,  # 인라이어만 그리기
                   flags=2)

result_img = cv2.drawMatches(img1, kp1, img2, kp2, matches, None, **draw_params)

# 결과 이미지 표시
cv2.imshow('RANSACal', result_img)
cv2.imwrite('RANSACal.jpg', result_img)

cv2.waitKey(0)
cv2.destroyAllWindows()
