import cv2
import numpy as np

img = cv2.imread('facepic.jpg')
rotated_img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
resized_img = cv2.resize(img, (0, 0), fx=0.25, fy=0.25)
resized_img = cv2.resize(resized_img, (img.shape[1], img.shape[0]))

sift = cv2.SIFT_create()
# 1
kp = sift.detect(img, None)
img_sift = cv2.drawKeypoints(img, kp, img)
# 2
rotated_kp = sift.detect(rotated_img, None)
rotated_img_sift = cv2.drawKeypoints(rotated_img, rotated_kp, rotated_img)
# 3
resized_kp = sift.detect(resized_img, None)
resized_img_sift = cv2.drawKeypoints(resized_img, resized_kp, resized_img)

cv2.imshow('SIFT Keypoints', img_sift)
cv2.imshow('rotated_SIFT Keypoints', rotated_img_sift)
cv2.imshow('resized_SIFT Keypoints', resized_img_sift)

cv2.imwrite('SIFT Keypoints.jpg', img_sift)
cv2.imwrite('SIFT rotated_Keypoints.jpg', rotated_img_sift)
cv2.imwrite('SIFT resized_Keypoints.jpg', resized_img_sift)

cv2.waitKey(0)
cv2.destroyAllWindows()