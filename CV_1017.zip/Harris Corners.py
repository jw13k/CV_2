import cv2
import numpy as np

# 1
img = cv2.imread('facepic.jpg')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
corners = cv2.cornerHarris(gray, 2, 3, 0.04)
img[corners > 0.01 * corners.max()] = [0, 0, 255]

# 2
rotated_img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
gray_rotated = cv2.cvtColor(rotated_img, cv2.COLOR_BGR2GRAY)
corners_rotated = cv2.cornerHarris(gray_rotated, 2, 3, 0.04)
rotated_img[corners_rotated > 0.01 * corners_rotated.max()] = [0, 0, 255]

# 3
resized_img = cv2.resize(img, (0, 0), fx=0.25, fy=0.25)
resized_img = cv2.resize(resized_img, (img.shape[1], img.shape[0]))
gray_resized = cv2.cvtColor(resized_img, cv2.COLOR_BGR2GRAY)
corners_resized = cv2.cornerHarris(gray_resized, 2, 3, 0.04)
resized_img[corners_resized > 0.01 * corners_resized.max()] = [0, 0, 255]

cv2.imshow('Harris Corners', img)
cv2.imshow('rotated_Harris Corners', rotated_img)
cv2.imshow('resized_Harris Corners', resized_img)

cv2.imwrite('Harris Corners.jpg', img)
cv2.imwrite('Harris rotated_Corners.jpg', rotated_img)
cv2.imwrite('Harris resized_Corners.jpg', resized_img)
cv2.waitKey(0)
cv2.destroyAllWindows()